
import redis

import psutil
import uuid
import time
from time import sleep
from time import time
from datetime import datetime
import argparse as ap


mac_address = hex(uuid.getnode())
parser = ap.ArgumentParser()

parser.add_argument('--host', default='', type=str, help="Default host change for others")
parser.add_argument('--port', default=0, type=int, help="Default port change for others")
parser.add_argument('--user', default='', type=str, help="Default user change for others")
parser.add_argument('--password', default='', type=str, help="Default password change for others")

args = parser.parse_args()

redis_client = redis.Redis(host=args.host, port=args.port, username=args.user, password=args.password)

is_connected = redis_client.ping()
print('Redis Connected:', is_connected)

bucket_1d_in_ms=86400000
one_mb_time_in_ms = 655359000
five_mb_time_in_ms = 3276799000


# Create a TimeSeries with chunk size 128 bytes
# By default, compression is enabled 
try:
    redis_client.flushall()
except redis.ResponseError:
    print("Cannot flush")
    pass
try:
    redis_client.ts().create('{mac_address}:battery', chunk_size=128, retention=five_mb_time_in_ms)
    redis_client.ts().create('{mac_address}:power', chunk_size=128, retention=five_mb_time_in_ms)
    redis_client.ts().create('{mac_address}:plugged_seconds', chunk_size=128, retention=one_mb_time_in_ms)
except redis.ResponseError:
    print("Cannot create some TimeSeries")
    pass
try:
    redis_client.ts().createrule('{mac_address}:power','{mac_address}:plugged_seconds','sum',bucket_1d_in_ms)
except redis.ResponseError:
    print("Cannot create rule")
    pass

######################################################

print("START")

while True:
    timestamp_ms = int(time() * 1000)
    battery_level = psutil.sensors_battery().percent
    power_plugged = int(psutil.sensors_battery().power_plugged)
   
    redis_client.ts().add('{mac_address}:battery', timestamp_ms, battery_level)
    redis_client.ts().add('{mac_address}:power', timestamp_ms, power_plugged)
   
    
    formatted_datetime = datetime.fromtimestamp(time() ).strftime('%Y-%m-%d %H:%M:%S.%f')
    print(f'{formatted_datetime} - {mac_address}:battery = {battery_level}')
    print(f'{formatted_datetime} - {mac_address}:power = {power_plugged}')
    
    sleep(1)